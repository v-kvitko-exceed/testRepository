import React from 'react';
import TodoApp from './components/TodoApp';
import './App.css';

function App() {
  var todoItems = [];
  todoItems.push({index: 1, value: "learn react", done: false});
  todoItems.push({index: 2, value: "Go shopping", done: true});
  todoItems.push({index: 3, value: "buy flowers", done: true});
  localStorage.getItem('todos') || localStorage.setItem('todos', JSON.stringify(todoItems))
  console.log('items', JSON.parse(localStorage.getItem('todos')))
  return (
    <TodoApp todoItems={JSON.parse(localStorage.getItem('todos'))}/>
  );
}

export default App;

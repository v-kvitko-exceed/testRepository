import React from 'react';

class TodoFooter extends React.Component {
  render () {
    return (
      <div>
        <button onClick={() => this.props.filterTodos('all')}>All</button>
        <button onClick={() => this.props.filterTodos('completed')}>Completed</button>
        <button type="button" className="close" onClick={this.onClickClose}>&times;</button>
      </div>
    )
  }
}

export default TodoFooter;

import React from 'react';
import TodoListItem from './_TodoListItem';
import '../App.css';

class TodoList extends React.Component {
  render () {
    console.log('data', this.props)
    var data = this.props.filtered.length ? this.props.filtered : this.props.items
    var items = data.map((item, index) => {
      return (
        <TodoListItem key={index} item={item} index={index} removeItem={this.props.removeItem} markTodoDone={this.props.markTodoDone} />
      );
    });
    return (
      <ul className="list-group"> {items} </ul>
    );
  }
}

export default TodoList;

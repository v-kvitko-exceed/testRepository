import React from 'react';

class TodoHeader extends React.Component {
  render () {
    return <h1>Todos</h1>;
  }
}

export default TodoHeader;

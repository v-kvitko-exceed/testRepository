import React from 'react';
import TodoList from './TodoList';
import TodoForm from './TodoForm';
import TodoFooter from './TodoFooter';
import TodoHeader from './TodoHeader';
import '../App.css';

class TodoApp extends React.Component {
  constructor (props) {
    super(props);
    this.addItem = this.addItem.bind(this);
    this.removeItem = this.removeItem.bind(this);
    this.markTodoDone = this.markTodoDone.bind(this);
    this.filterTodos = this.filterTodos.bind(this);
    
    this.state = {
      todoItems: this.props.todoItems,
      filteredItems: []
    };
  }
  addItem(todoItem) {
    this.props.todoItems.unshift({
      index: this.props.todoItems.length+1, 
      value: todoItem.newItemValue, 
      done: false
    });

    localStorage.setItem('todos', JSON.stringify(this.props.todoItems));
    this.setState({todoItems: this.props.todoItems});
  }
  removeItem (itemIndex) {
    this.props.todoItems.splice(itemIndex, 1);
    localStorage.setItem('todos', JSON.stringify(this.props.todoItems));
    this.setState({todoItems: this.props.todoItems});
  }
  markTodoDone(itemIndex) {
    var todo = this.props.todoItems[itemIndex];
    this.props.todoItems.splice(itemIndex, 1);
    todo.done = !todo.done;
    todo.done ? this.props.todoItems.push(todo) : this.props.todoItems.unshift(todo);

    localStorage.setItem('todos', JSON.stringify(this.props.todoItems));
    this.setState({todoItems: this.props.todoItems});  
  }
  filterTodos(filter) {
    if (filter === 'all'){
      this.setState({filteredItems: []})
      return
    }
    let filtered = this.props.todoItems.filter((item) => {
      return item.done === (filter === 'active' ? false : true);
    });

    this.setState({filteredItems: filtered});
  }
  
  render() {
    return (
      <div id="main">
        <TodoHeader />
        <TodoList items={this.props.todoItems} filtered={this.state.filteredItems} removeItem={this.removeItem} markTodoDone={this.markTodoDone}/>
        <TodoForm addItem={this.addItem} />
        <TodoFooter filterTodos={this.filterTodos} />
      </div>
    );
  }
}

export default TodoApp;

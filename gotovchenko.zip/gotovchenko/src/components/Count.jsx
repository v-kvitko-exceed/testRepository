import React from 'react';
//import './App.css';


class Count extends React.Component {
    render() { 
    //console.log('THIS PROPS',this.props.todos.length)
    const activeCount = this.props.todos.filter((item) => !item.complete)
    return (
        <div className="count">
          Active item:
          <h4>{activeCount.length}</h4> 
        </div>
    )
}
}
export default Count;

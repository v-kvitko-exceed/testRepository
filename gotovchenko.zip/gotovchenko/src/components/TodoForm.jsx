import React from 'react';
//import './App.css';

class TodoForm extends React.Component {
    constructor(props) {
      super(props);
      this.state = { value: "" };
      this.onChange = this.onChange.bind(this);
      this.onSubmit = this.onSubmit.bind(this);
    }
    render() {
        return (
          
            <div>
                <input 
                className="inputbtn"
                  type="text" 
                  placeholder="What needs to be done?"
                  value={this.state.value}
                  onChange={this.onChange}
                  />
                  <button 
                    onClick={this.onSubmit}
                    > Add
                  </button>
                
          </div>      
        );
    }
  
    onSubmit() {
      this.props.addTodo(this.state.value);
      this.setState({ value: "" });
    }
    onChange(e) {
      this.setState({ value: e.target.value });
    }
  }
  export default TodoForm;

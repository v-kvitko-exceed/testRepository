import React from 'react';
//import './App.css';

class Todo extends React.Component {
  //constructor(props) {super(props)}

  render() {
    //console.log('todo', this.props.id, this.props.completed)
    return (
      <div >
          { this.props.completed ?
            <input className="inputcheck" onClick={()=> this.props.toggle(this.props.id)} checked={true} type="checkbox" /> 
            :
            <input onClick={()=> this.props.toggle(this.props.id)} type="checkbox" /> }
          <span className="input">{this.props.text}</span>
          <button className="del" onClick={()=> this.props.deleteTodo(this.props.id) }> Del</button>
        </div>
     
    );
  }
}


export default Todo;

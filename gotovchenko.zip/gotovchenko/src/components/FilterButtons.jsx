import React from 'react';
//import './App.css';

function FilterButtons({ mode, setFilter, deleteCompleted }) {
    return (
          <div className="btn">
          <button
            className={`${mode === 1 ? "active" : ""}`}
           
            onClick={() => setFilter(1)}
          >All</button>
          <button
            className={` ${mode === 2 ? "active" : ""}`}
            
            onClick={() => setFilter(2)}
          >Active</button>
          <button
            className={` ${mode === 3 ? "active" : ""}`}
            
            onClick={() => setFilter(3)}
          >Completed</button>
          <button onClick={deleteCompleted}
            >Clear Completed </button>
        </div>
        
    );
  }
  export default FilterButtons;

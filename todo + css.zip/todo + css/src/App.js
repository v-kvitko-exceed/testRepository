import React from 'react';
import TodoApp from './components/TodoApp';
import './components/App.css';

function App() {
  return (
    <div className="fr"><TodoApp /></div>);
}

export default App;
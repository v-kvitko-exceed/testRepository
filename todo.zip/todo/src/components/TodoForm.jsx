import React from 'react';
import './App.css';

class TodoForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = { value: "" };
    this.onChange = this.onChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }


  render() {
    return (
      <div className="inputForm">

        <input
          className="inputText"
          type="text"
          placeholder="    What needs to be done?"
          value={this.state.value}
          onChange={this.onChange}
          onKeyDown={this.handleSubmit} />
        <label className="all">
          <input
            className="option-input checkboxl"
            type="checkbox"
            onClick={(e) => this.props.allCheck(e)} 
            
            checked={this.props.mainCheckbox ? true : false} 
            />
        </label>



      </div>
    );
  }

  handleSubmit(e) {
    if (e.which === 13) {
      this.props.addTodo(this.state.value);
      this.setState({ value: "" });
    }
  }


  onChange(e) {
    this.setState({ value: e.target.value });
  }
}
export default TodoForm;

import React from 'react';
import TodoApp from './components/TodoApp';
import './components/App.css';

import 'react-toastify/dist/ReactToastify.min.css'; 

function App() {
  return (
    <div className="fr"><TodoApp /></div>);
}

export default App;